//create app from express framework
const express = require('express');
    //instance of app
    const app = express();

//connection with packages and use them
const bodyParser = require('body-parser');
const cors = require('cors');
app.use(cors());
/*middle*/
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//intialize host port of server
const port = 9000;
const server = app.listen(port , ()=>{
    console.log("running on localhost: " + port)
});

//reading from (conect) project folder website
app.use(express.static('website'));


//empty object of data that will be fulled
const projectData = {};
//get data from specific path
app.get('/getData', function (req, res) {
	res.send(projectData);
	console.log(projectData);
	});


//take data from user
app.post('/postData', function(req,res){
    let data = req.body;
    console.log(data);
    projectData['main'] = data.main;
    projectData['feelings'] = data.feelings;
    projectData['date'] = data.date;
    res.send(projectData);
} );
