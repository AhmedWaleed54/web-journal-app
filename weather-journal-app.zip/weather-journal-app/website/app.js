//intialize the api key and its base URL
const baseURL = 'http://api.openweathermap.org/data/2.5/weather?units=metric&zip=';
const apiKey = '&appid=282960ab649897b53d2b5e331438abe4';
//const feelings = document.getElementById('feelings').value;//get user feelings
//const zipCode = document.getElementById('zip').value;//get zip code

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();


//Add event listener (function) while clicking in the button generate
document.getElementById('generate').addEventListener('click',()=>{
  const feelings = document.getElementById('feelings').value;//get user feelings
  const zipCode = document.getElementById('zip').value;//get zip code
  //callig function getData which get the data from api
  getData(zipCode).then(function(data){
    //calling function post data to postData and save it in our server
    postData('/postData' , {main:data.main , feelings:feelings, date: newDate}).then(()=>{
      //show the data in  UI (client side) by getting them from our server/getData 
      updateUI("/getData")})
  });
});


//function for getting data from API
const getData = async (zipCode)=>{
//fetch the data
  const request = await fetch(`http://api.openweathermap.org/data/2.5/weather?units=metric&zip=${zipCode}${apiKey}`);
  // if there is error ,error message apears
  //  (Try , catch )to find and handle the error
  try {
    const data = await request.json();
    console.log(data)
    return data;
  }  
  catch(error) {
    console.log("something is wrong !", error);
  }
}


//function for posting and saving data in our server 
const postData = async ( url = '', data = {})=>{
  console.log(data);
  //fetch the data 
    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin',
    headers: {
        'Content-Type': 'application/json',
    },
   // Body of data type must be "Content-Type" header        
    body: JSON.stringify(data), 
  });
// if there is error ,error message apears
//  (Try , catch )to find and handle the error
    try {
      const neData = await response.json();
      return neData;
    }
    catch(error) {
    console.log("something is wrong !", error);
    }
}


//function to put data in UI
const updateUI = async (url)=>{
//Calling function to get the data 
let data = await getALLData(url);
// show the data on UI (cheint side)
document.getElementById('date').innerHTML = data.date;
document.getElementById('temp').innerHTML = data.main.temp;
document.getElementById('content').innerHTML=data.feelings;
}


//function to receive data from our server to put it next in our UI (CLEINT SIDE)
const getALLData = async (url='') =>{ 
const request = await fetch(url);
// if there is error ,error message apears
// (Try , catch )to find and handle the error
  try {
    // Transform data into JSON for easy reading
    const dataALL = await request.json();
    return dataALL;
  }
  catch(error) {
    console.log("something is wrong !", error); 
  }
}




